import React from "react";
import VerifiedLeadsTable from "./VerifiedLeadsTable";

export default function Verified() {
  return (
    <div>
      <VerifiedLeadsTable />
    </div>
  );
}
